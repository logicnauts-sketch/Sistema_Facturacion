import mysql.connector

def conectar():
    try:
        conn = mysql.connector.connect(
            user="pruebasistema",
            password="jarabacoa123",
            host="pruebasistema.mysql.pythonanywhere-services.com",
            database="pruebasistema$default"
        )
        if conn.is_connected():
            print("Conexión exitosa.")
        return conn
    except mysql.connector.Error as e:
        print(f"Error al conectarse a la base de datos: {e}")
        return None


def obtener_ip_agente():
    """Obtiene la IP del agente de impresión desde la base de datos"""
    conn = conectar()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT valor FROM configuracion WHERE clave = 'agente_ip'")
        config = cursor.fetchone()
        return config['valor'] if config else None
    except Exception as e:
        print(f"Error al obtener IP del agente: {str(e)}")
        return None
    finally:
        cursor.close()
        conn.close()

def guardar_ip_agente(ip):
    """Guarda la IP del agente de impresión en la base de datos"""
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO configuracion (clave, valor) 
            VALUES ('agente_ip', %s)
            ON DUPLICATE KEY UPDATE valor = %s
        """, (ip, ip))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error al guardar IP del agente: {str(e)}")
        return False
    finally:
        cursor.close()
        conn.close()